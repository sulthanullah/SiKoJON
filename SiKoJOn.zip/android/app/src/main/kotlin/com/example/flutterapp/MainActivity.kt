package com.example.flutterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
